# YR Badminton Admin v2

This package is pre-filled with API_BASE:
https://script.google.com/macros/s/AKfycbwv5Db3ePyGuiTDOGFDM8joTprsOmL3xpymGPVOv3ocaPeTb-QTEPySqafNxY_LhJwm/exec

Admin features:
- Sessions table: inline edit all fields, save, delete session, set-only-open, bulk save.
- RSVPs table: view bookings by session, filter YES/NO, edit name/status/pax/note, delete booking.

IMPORTANT:
You must update Apps Script to support the new admin actions listed in the chat message and redeploy as a new version.
